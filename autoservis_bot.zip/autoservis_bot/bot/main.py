"""
AutoServis Finder — Telegram Bot
Bu fayl botni ishga tushiradi va foydalanuvchiga Mini App ni ochish tugmasini ko'rsatadi.
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

# =============================================
# SOZLAMALAR — bularni o'zingiznikiga almashtiring
# =============================================
BOT_TOKEN = "BU_YERGA_BOT_TOKENINGIZNI_YOZING"   # @BotFather dan olasiz
MINIAPP_URL = "BU_YERGA_MINIAPP_URLINI_YOZING"   # Vercel deploy qilgandan keyin

# Logging — xatolarni ko'rish uchun
logging.basicConfig(level=logging.INFO)


# /start buyrug'i
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    keyboard = [
        [InlineKeyboardButton(
            text="🔧 AutoServis Finder ni ochish",
            web_app=WebAppInfo(url=MINIAPP_URL)
        )]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(
        f"Salom, {user.first_name}! 👋\n\n"
        "🚗 AutoServis Finder — yaqin atrofdagi ustaxonalarni toping!\n\n"
        "Pastdagi tugmani bosing:",
        reply_markup=reply_markup
    )


# /help buyrug'i
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📌 Buyruqlar:\n"
        "/start — Botni boshlash\n"
        "/help — Yordam\n\n"
        "Savollar uchun: @sizning_username"
    )


# Botni ishga tushirish
if __name__ == "__main__":
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    print("✅ Bot ishga tushdi...")
    app.run_polling()
